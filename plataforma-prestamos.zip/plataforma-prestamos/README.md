# Plataforma de préstamo de recursos tecnológicos

Proyecto integrador de Ingeniería de Software. Aplicación web con API REST (Spring Boot) y base de datos H2.

## Tecnologías
- Java 17 o superior, Maven 3.9+ (o el Maven de IntelliJ/Eclipse/VS Code)
- Spring Boot 3.3.5 (Web, Data JPA), H2 en memoria, JUnit 5
- Portal web estático (HTML + JS) servido por la misma aplicación

## Ejecutar
```bash
mvn spring-boot:run
```
Abrir http://localhost:8080 (consola H2: http://localhost:8080/h2-console, JDBC URL `jdbc:h2:mem:prestamos`, usuario `sa`, sin clave).
Los datos iniciales se cargan solos al arrancar (la base se reinicia en cada ejecución).

## Cuentas de demostración (clave: `demo123`)
| Rol | Correo | Sede |
|---|---|---|
| Estudiante | estudiante1@demo.edu, estudiante2@demo.edu | - |
| Profesor | profesor1@demo.edu | - |
| Auxiliar | auxiliar.norte@demo.edu / auxiliar.sur@demo.edu | Norte / Sur |
| Coordinador | coordinador@demo.edu | ambas |
| Mantenimiento | mantenimiento@demo.edu | ambas |
| Dirección | direccion@demo.edu | ambas |

Inventario: Portátil (PORT-N-01, PORT-N-02, PORT-S-01), Cámara (CAM-N-01, CAM-S-01) y Kit de robótica, especializado (ROB-N-01, ROB-S-01).

## Pruebas
```bash
mvn test
```
`FlujosPrincipalesTest` cubre los escenarios del apartado 9: confirmación estándar, franjas consecutivas, última unidad concurrente, aprobación con revalidación, rechazo, cancelación, vencimiento (minutos 30 y 31), retiro, devolución tardía, daño con reservas afectadas, reactivación, fallo de correo, permisos y bloqueo.

| Caso | Requisito | Prueba (método) |
|---|---|---|
| CP-01 | RF-04, RF-16 | confirmacionEstandar |
| CP-02 | RF-08, RN-02 | franjasConsecutivas |
| CP-03 | RNF-02, RN-03 | ultimaUnidadConcurrente |
| CP-04 | RF-06, RN-07 | aprobacionConRevalidacion |
| CP-05 | RF-07, RN-08 | rechazoExigeJustificacion |
| CP-06 | RF-11, RN-11 | cancelacion |
| CP-07 | RF-10, RN-10 | vencimientoSinRetiro |
| CP-08 | RF-09, 12, 13, 14, 15, 17 | devolucionTardiaConDanoYReactivacion |
| CP-09 | RNF-05, RN-14 | falloDeCorreoNoRevierteReserva |
| CP-10 | RF-18, RNF-06 | permisosYPrivacidad |
| CP-11 | S-01 | bloqueoPorTardanzas |
| CP-12 | Diagrama de estados de la unidad | estadosDeLaUnidad |
| CP-13 | Diagrama de clases (Rol, Devolucion, Incidente) | modeloRolDevolucionIncidente |

## Simulación para la demostración (rol Coordinador, panel «Simulación»)
- **Reloj:** `POST /api/sim/reloj?minutos=31` avanza la hora; `POST /api/sim/vencer` aplica la regla de los 30 minutos (también corre cada minuto con el planificador).
- **Correo:** `POST /api/sim/correo?modo=ERROR` deja el aviso FALLIDO; `modo=SIN_CONEXION` lo deja PENDIENTE (sede con conexión intermitente); `modo=OK` lo envía. En todos los casos la reserva sigue confirmada y el aviso se reintenta desde el portal.

## Estructura (coincide con los diagramas)
| Componente del diagrama | Clases |
|---|---|
| Portal Web | `static/index.html` |
| Controladores API | `ControladorAcceso`, `ControladorInventario`, `ControladorReservas`, `ControladorPrestamos`, `ControladorAdmin` |
| Autenticación y Roles | `ServicioAutenticacion`, `AuthFilter`, entidades `Rol` y `Usuario` |
| Catálogo e Inventario | `InventarioUnidad` (`buscarUnidadDisponible`, estado de la unidad), `TipoEquipo`, `Unidad` |
| Servicio de Reservas | `ServicioReservas` (`validarElegibilidad`), `Solicitud`, `Reserva` |
| Planificador de Vencimientos | `PlanificadorVencimientos`, `PlanificadorConfig` |
| Préstamos y Devoluciones | `ServicioPrestamos` (retiro), `ServicioDevoluciones`, `Prestamo`, `Devolucion` |
| Incidentes y Mantenimiento | `ServicioIncidentes`, `Incidente` |
| Servicio de Notificaciones | `ServicioNotificaciones`, `Notificacion` |
| Auditoría e Historial | `ServicioHistorial`, `HistorialCambio` |
| Acceso a datos (BD relacional) | `Repos.java` (repositorios JPA), `Atomico` (transacciones atómicas) |

## Estados
- **Unidad:** DISPONIBLE, RESERVADA, PRESTADA, FUERA_DE_CIRCULACION (`InventarioUnidad.sincronizarEstado`).
- **Reserva:** CONFIRMADA, CANCELADA, VENCIDA. El retiro crea un `Prestamo`; no cambia el estado de la reserva.
- **Solicitud:** PENDIENTE, CONFIRMADA, RECHAZADA, NO_CONFIRMADA. **Aviso:** ENVIADO, PENDIENTE, FALLIDO.

## Concurrencia
Toda asignación, cancelación, retiro, devolución e incidente pasa por `Atomico`: un único candado y una transacción completa (RN-03). Es válido para una sola instancia de la aplicación.

## Supuestos
S-01 bloqueo tras 2 tardías en 30 días (`app.bloqueo.umbral`); S-02 margen 0 min; S-03 reservas afectadas sin reasignación automática; S-04 hora pactada = fin de la franja; S-07 retiro válido hasta el minuto 30 inclusive (`app.vencimiento.minutos`); S-08 primera unidad libre. Las claves de prueba se guardan con SHA-256 y las sesiones son tokens en memoria (solo para demostración).
