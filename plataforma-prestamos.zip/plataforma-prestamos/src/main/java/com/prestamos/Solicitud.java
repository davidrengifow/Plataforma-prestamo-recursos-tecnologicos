package com.prestamos;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.prestamos.Enums.*;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Solicitud {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @ManyToOne
    public Usuario solicitante;
    @ManyToOne
    public TipoEquipo tipo;
    @ManyToOne
    public Sede sede;
    public LocalDateTime inicio;
    public LocalDateTime fin;
    @Enumerated(EnumType.STRING)
    public EstadoSolicitud estado;
    public String motivo;
    public LocalDateTime creada;
}
