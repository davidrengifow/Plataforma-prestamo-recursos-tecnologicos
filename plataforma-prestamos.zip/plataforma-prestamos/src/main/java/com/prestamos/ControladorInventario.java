package com.prestamos;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ControladorInventario {
    private final InventarioUnidad inventario; private final SedeRepo sedes;

    ControladorInventario(InventarioUnidad inventario, SedeRepo sedes) { this.inventario = inventario; this.sedes = sedes; }

    @GetMapping("/sedes") public List<Sede> sedes() { return sedes.findAll(); }

    @GetMapping("/catalogo") public List<TipoEquipo> catalogo() { return inventario.catalogo(); }

    @GetMapping("/disponibilidad")
    public List<Unidad> disponibilidad(@RequestParam Long tipoId, @RequestParam Long sedeId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime inicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fin) {
        return inventario.disponibles(tipoId, sedeId, inicio, fin);
    }
}
