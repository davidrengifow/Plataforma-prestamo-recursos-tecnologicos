package com.prestamos;

import com.prestamos.Enums.*;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Componente «Servicio de Notificaciones» (RN-14, RF-16, RF-22). El correo es simulado:
 * OK -> ENVIADO; SIN_CONEXION -> queda PENDIENTE; ERROR -> FALLIDO. Nunca revierte la reserva (RNF-05).
 */
@Service
public class ServicioNotificaciones {
    private static final Logger log = LoggerFactory.getLogger(ServicioNotificaciones.class);
    private final NotificacionRepo repo;
    private final ClockService reloj;
    private final AtomicReference<ModoCorreo> modo = new AtomicReference<>(ModoCorreo.OK);

    ServicioNotificaciones(NotificacionRepo repo, ClockService reloj) { this.repo = repo; this.reloj = reloj; }

    public void simularModo(ModoCorreo m) { modo.set(m); }
    public ModoCorreo modoActual() { return modo.get(); }

    /** Registra el aviso y lo intenta enviar. Nunca lanza excepción. */
    public void avisar(Usuario destinatario, Long solicitudId, Long reservaId, String evento, String detalle) {
        try {
            Notificacion n = new Notificacion();
            n.destinatario = destinatario; n.solicitudId = solicitudId; n.reservaId = reservaId;
            n.evento = evento; n.detalle = detalle; n.creada = reloj.now();
            n.estado = EstadoAviso.PENDIENTE;
            enviar(repo.save(n));
        } catch (Exception e) {
            log.warn("No se pudo registrar el aviso {}: {}", evento, e.getMessage());
        }
    }

    public Notificacion reintentar(Long id) {
        Notificacion n = repo.findById(id).orElseThrow(() -> new ApiException(404, "Aviso no encontrado"));
        if (n.estado == EstadoAviso.ENVIADO) throw new ApiException(409, "El aviso ya fue enviado");
        return enviar(n);
    }

    public List<Notificacion> listar() { return repo.findAllByOrderByCreadaDesc(); }

    private Notificacion enviar(Notificacion n) {
        switch (modo.get()) {
            case OK -> {
                log.info("[CORREO SIMULADO] a {}: {} - {}", n.destinatario.correo, n.evento, n.detalle);
                n.estado = EstadoAviso.ENVIADO;
            }
            case SIN_CONEXION -> n.estado = EstadoAviso.PENDIENTE;
            case ERROR -> n.estado = EstadoAviso.FALLIDO;
        }
        return repo.save(n);
    }
}
