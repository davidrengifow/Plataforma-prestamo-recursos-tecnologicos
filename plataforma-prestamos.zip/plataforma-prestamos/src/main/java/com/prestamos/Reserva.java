package com.prestamos;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.prestamos.Enums.*;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Reserva {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @ManyToOne
    public Solicitud solicitud;
    @ManyToOne
    public Unidad unidad;
    @ManyToOne
    public Usuario titular;
    public LocalDateTime inicio;
    public LocalDateTime fin;
    @Enumerated(EnumType.STRING)
    public EstadoReserva estado;
    public boolean afectada;
}
