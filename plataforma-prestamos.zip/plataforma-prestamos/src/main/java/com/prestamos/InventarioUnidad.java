package com.prestamos;

import com.prestamos.Enums.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.springframework.stereotype.Service;

/** Componente «Catálogo e Inventario» (RF-01, RF-02): tipos, unidades, disponibilidad y estado de cada unidad. */
@Service
public class InventarioUnidad {
    private static final Set<EstadoReserva> OCUPAN = Set.of(EstadoReserva.CONFIRMADA);

    private final TipoRepo tipos; private final UnidadRepo unidades; private final ReservaRepo reservas;
    private final PrestamoRepo prestamos; private final ClockService reloj;

    InventarioUnidad(TipoRepo tipos, UnidadRepo unidades, ReservaRepo reservas, PrestamoRepo prestamos, ClockService reloj) {
        this.tipos = tipos; this.unidades = unidades; this.reservas = reservas; this.prestamos = prestamos; this.reloj = reloj;
    }

    public List<TipoEquipo> catalogo() { return tipos.findAll(); }

    public TipoEquipo tipo(Long id) {
        return tipos.findById(id).orElseThrow(() -> new ApiException(404, "Tipo de equipo no encontrado"));
    }

    public List<Unidad> disponibles(Long tipoId, Long sedeId, LocalDateTime ini, LocalDateTime fin) {
        validarFranja(ini, fin);
        TipoEquipo tipo = tipo(tipoId);
        List<Unidad> libres = new ArrayList<>();
        for (Unidad u : candidatas(tipo, sedeId)) if (estaLibre(u, tipo, ini, fin)) libres.add(u);
        return libres;
    }

    /** S-08: primera unidad en servicio y libre en la franja, o null si no hay. */
    public Unidad buscarUnidadDisponible(TipoEquipo tipo, Long sedeId, LocalDateTime ini, LocalDateTime fin) {
        for (Unidad u : candidatas(tipo, sedeId)) if (estaLibre(u, tipo, ini, fin)) return u;
        return null;
    }

    /**
     * Mantiene el estado de la unidad según el diagrama de estados: DISPONIBLE, RESERVADA (tiene una reserva
     * confirmada sin retirar), PRESTADA (préstamo activo). FUERA_DE_CIRCULACION solo lo cambian incidente y mantenimiento.
     */
    public void sincronizarEstado(Unidad u) {
        if (u.estado == EstadoUnidad.FUERA_DE_CIRCULACION) return;
        EstadoUnidad nuevo;
        if (prestamos.existsByReservaUnidadIdAndActivoTrue(u.id)) nuevo = EstadoUnidad.PRESTADA;
        else if (reservas.findByUnidadIdAndEstado(u.id, EstadoReserva.CONFIRMADA).stream()
                .anyMatch(r -> r.fin.isAfter(reloj.now()) && prestamos.findByReservaId(r.id).isEmpty())) nuevo = EstadoUnidad.RESERVADA;
        else nuevo = EstadoUnidad.DISPONIBLE;
        if (nuevo != u.estado) { u.estado = nuevo; unidades.save(u); }
    }

    private List<Unidad> candidatas(TipoEquipo tipo, Long sedeId) {
        return unidades.findByTipoIdAndSedeIdAndEstadoNotOrderByCodigo(tipo.id, sedeId, EstadoUnidad.FUERA_DE_CIRCULACION);
    }

    /** RN-02 / S-02: sin superposición; franjas consecutivas válidas (margen por tipo, 0 en v1). */
    private boolean estaLibre(Unidad u, TipoEquipo tipo, LocalDateTime ini, LocalDateTime fin) {
        int m = tipo.margenPreparacionMin;
        return reservas.findOcupadas(u.id, ini.minusMinutes(m), fin.plusMinutes(m), OCUPAN).isEmpty();
    }

    public static void validarFranja(LocalDateTime ini, LocalDateTime fin) {
        if (ini == null || fin == null || !ini.isBefore(fin))
            throw new ApiException(400, "La hora de inicio debe ser anterior a la hora de fin");
    }
}
