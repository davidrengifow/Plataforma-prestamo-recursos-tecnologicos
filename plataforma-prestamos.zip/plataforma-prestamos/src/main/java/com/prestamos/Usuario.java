package com.prestamos;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.prestamos.Enums.*;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Usuario {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    public String nombre;
    @Column(unique = true)
    public String correo;
    @JsonIgnore
    public String passwordHash;
    @ManyToOne
    public Rol rol;
    @ManyToOne
    public Sede sede;
    public boolean bloqueado;
    public int devolucionesTardias30d;
}
