package com.prestamos;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.prestamos.Enums.*;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Incidente {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @ManyToOne
    public Unidad unidad;
    @ManyToOne
    public Devolucion devolucion;
    public String descripcion;
    public LocalDateTime fecha;
    @ManyToOne
    public Usuario registradoPor;
}
