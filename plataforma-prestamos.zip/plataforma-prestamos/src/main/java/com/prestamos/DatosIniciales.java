package com.prestamos;

import com.prestamos.Enums.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/** Cuentas de prueba por rol e inventario inicial (clave de todas las cuentas: demo123). */
@Component
public class DatosIniciales implements CommandLineRunner {
    private final SedeRepo sedes; private final TipoRepo tipos; private final UnidadRepo unidades; private final UsuarioRepo usuarios;
    private final RolRepo roles;

    DatosIniciales(SedeRepo sedes, TipoRepo tipos, UnidadRepo unidades, UsuarioRepo usuarios, RolRepo roles) {
        this.sedes = sedes; this.tipos = tipos; this.unidades = unidades; this.usuarios = usuarios; this.roles = roles;
    }

    @Override
    public void run(String... args) {
        if (sedes.count() > 0) return;
        for (NombreRol n : NombreRol.values()) { Rol r = new Rol(); r.nombre = n; roles.save(r); }
        Sede norte = sede("Sede Norte"), sur = sede("Sede Sur");
        TipoEquipo portatil = tipo("Portátil", false), camara = tipo("Cámara", false), robotica = tipo("Kit de robótica", true);
        unidad("PORT-N-01", portatil, norte); unidad("PORT-N-02", portatil, norte); unidad("PORT-S-01", portatil, sur);
        unidad("CAM-N-01", camara, norte);    unidad("CAM-S-01", camara, sur);
        unidad("ROB-N-01", robotica, norte);  unidad("ROB-S-01", robotica, sur);

        usuario("Estudiante Uno", "estudiante1@demo.edu", NombreRol.ESTUDIANTE, null);
        usuario("Estudiante Dos", "estudiante2@demo.edu", NombreRol.ESTUDIANTE, null);
        usuario("Profesor Uno", "profesor1@demo.edu", NombreRol.PROFESOR, null);
        usuario("Auxiliar Norte", "auxiliar.norte@demo.edu", NombreRol.AUXILIAR, norte);
        usuario("Auxiliar Sur", "auxiliar.sur@demo.edu", NombreRol.AUXILIAR, sur);
        usuario("Coordinador", "coordinador@demo.edu", NombreRol.COORDINADOR, null);
        usuario("Mantenimiento", "mantenimiento@demo.edu", NombreRol.MANTENIMIENTO, null);
        usuario("Dirección", "direccion@demo.edu", NombreRol.DIRECCION, null);
    }

    private Sede sede(String n) { Sede s = new Sede(); s.nombre = n; return sedes.save(s); }
    private TipoEquipo tipo(String n, boolean esp) { TipoEquipo t = new TipoEquipo(); t.nombre = n; t.especializado = esp; return tipos.save(t); }
    private void unidad(String c, TipoEquipo t, Sede s) {
        Unidad u = new Unidad(); u.codigo = c; u.tipo = t; u.sede = s; u.estado = EstadoUnidad.DISPONIBLE; unidades.save(u);
    }
    private void usuario(String n, String correo, NombreRol rol, Sede s) {
        Usuario u = new Usuario(); u.nombre = n; u.correo = correo; u.rol = roles.findAll().stream().filter(x -> x.nombre == rol).findFirst().orElseThrow(); u.sede = s;
        u.passwordHash = ServicioAutenticacion.hash("demo123"); usuarios.save(u);
    }
}
