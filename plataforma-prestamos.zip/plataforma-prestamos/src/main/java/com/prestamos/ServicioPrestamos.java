package com.prestamos;

import static com.prestamos.ServicioAutenticacion.exigir;

import com.prestamos.Enums.*;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/** Componente «Préstamos y Devoluciones» (parte de retiro, RF-09). */
@Service
public class ServicioPrestamos {
    public record PrestamoVista(Prestamo prestamo, Devolucion devolucion) {}

    private final ReservaRepo reservas; private final PrestamoRepo prestamos; private final DevolucionRepo devoluciones;
    private final InventarioUnidad inventario; private final ServicioHistorial historial; private final ClockService reloj;
    private final Atomico atomico; private final int minutosVencimiento;

    ServicioPrestamos(ReservaRepo reservas, PrestamoRepo prestamos, DevolucionRepo devoluciones, InventarioUnidad inventario,
                      ServicioHistorial historial, ClockService reloj, Atomico atomico,
                      @Value("${app.vencimiento.minutos:30}") int minutosVencimiento) {
        this.reservas = reservas; this.prestamos = prestamos; this.devoluciones = devoluciones; this.inventario = inventario;
        this.historial = historial; this.reloj = reloj; this.atomico = atomico; this.minutosVencimiento = minutosVencimiento;
    }

    public List<PrestamoVista> mios(Usuario u) {
        List<PrestamoVista> salida = new ArrayList<>();
        for (Prestamo p : prestamos.findByReservaTitularIdOrderByRetiroEnDesc(u.id))
            salida.add(new PrestamoVista(p, devoluciones.findByPrestamoId(p.id).orElse(null)));
        return salida;
    }

    /** RN-09: verifica identidad, reserva y código del equipo; el registro inicia el préstamo. */
    public Prestamo retirar(Usuario aux, Long reservaId, String codigoUnidad, String condicion, boolean identidadVerificada) {
        exigir(aux, NombreRol.AUXILIAR);
        if (!identidadVerificada) throw new ApiException(400, "Debe verificar la identidad de la persona");
        return atomico.ejecutar(() -> {
            Reserva r = reservas.findById(reservaId).orElseThrow(() -> new ApiException(404, "Reserva no encontrada"));
            if (!aux.sede.id.equals(r.unidad.sede.id)) throw new ApiException(403, "El retiro debe hacerse en la sede de la reserva");
            if (r.estado != EstadoReserva.CONFIRMADA) throw new ApiException(409, "La reserva no está disponible para retiro (estado " + r.estado + ")");
            if (prestamos.findByReservaId(r.id).isPresent()) throw new ApiException(409, "La reserva ya fue retirada");
            if (r.unidad.estado == EstadoUnidad.FUERA_DE_CIRCULACION) throw new ApiException(409, "La unidad está fuera de circulación");
            if (codigoUnidad == null || !codigoUnidad.equalsIgnoreCase(r.unidad.codigo))
                throw new ApiException(400, "El código del equipo no corresponde a la reserva");
            if (reloj.now().isAfter(r.inicio.plusMinutes(minutosVencimiento)))
                throw new ApiException(409, "La reserva venció: pasaron más de " + minutosVencimiento + " minutos del inicio");
            Prestamo p = new Prestamo();
            p.reserva = r; p.auxiliarRetiro = aux; p.retiroEn = reloj.now();
            p.condicionEntrega = condicion; p.activo = true;
            p = prestamos.save(p);
            inventario.sincronizarEstado(r.unidad); // pasa a PRESTADA
            historial.registrar(aux, "Prestamo", p.id, "RETIRO", "Unidad " + r.unidad.codigo + " - " + condicion);
            return p;
        });
    }
}
