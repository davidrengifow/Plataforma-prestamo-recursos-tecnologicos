package com.prestamos;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/** Componente «Planificador de Vencimientos» (RF-10): aplica la regla de los 30 minutos cada minuto. */
@Component
@ConditionalOnProperty(name = "app.planificador.activo", havingValue = "true", matchIfMissing = true)
public class PlanificadorVencimientos {
    private final ServicioReservas reservas;

    PlanificadorVencimientos(ServicioReservas reservas) { this.reservas = reservas; }

    @Scheduled(fixedRate = 60_000)
    public void aplicarVencimientos() { reservas.vencerReservas(); }
}
