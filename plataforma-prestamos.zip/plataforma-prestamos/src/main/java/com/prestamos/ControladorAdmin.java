package com.prestamos;

import static com.prestamos.ServicioAutenticacion.exigir;

import com.prestamos.Enums.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

/** Avisos, historial, informes y simulación para la demostración. */
@RestController
@RequestMapping("/api")
public class ControladorAdmin {
    private final ServicioNotificaciones avisos; private final ServicioHistorial historial; private final ServicioInformes informes;
    private final ServicioReservas reservas; private final ClockService reloj;

    ControladorAdmin(ServicioNotificaciones avisos, ServicioHistorial historial, ServicioInformes informes,
                     ServicioReservas reservas, ClockService reloj) {
        this.avisos = avisos; this.historial = historial; this.informes = informes; this.reservas = reservas; this.reloj = reloj;
    }

    @GetMapping("/notificaciones")
    public List<Notificacion> notificaciones(@RequestAttribute("usuario") Usuario u) {
        exigir(u, NombreRol.AUXILIAR, NombreRol.COORDINADOR);
        return avisos.listar();
    }
    @PostMapping("/notificaciones/{id}/reintentar")
    public Notificacion reintentar(@RequestAttribute("usuario") Usuario u, @PathVariable Long id) {
        exigir(u, NombreRol.AUXILIAR, NombreRol.COORDINADOR);
        return avisos.reintentar(id);
    }
    @GetMapping("/historial") public List<HistorialCambio> historial(@RequestAttribute("usuario") Usuario u) { return historial.listar(u); }
    @GetMapping("/informes") public List<Map<String, Object>> informes(@RequestAttribute("usuario") Usuario u) { return informes.porSede(u); }

    @GetMapping("/sim/estado")
    public Map<String, Object> simEstado(@RequestAttribute("usuario") Usuario u) {
        exigir(u, NombreRol.COORDINADOR);
        return Map.of("ahora", reloj.now().toString(), "relojSimulado", reloj.simulado(), "correo", avisos.modoActual().name());
    }
    @PostMapping("/sim/reloj")
    public Map<String, Object> simReloj(@RequestAttribute("usuario") Usuario u, @RequestParam(required = false) Long minutos,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fijar,
            @RequestParam(defaultValue = "false") boolean real) {
        exigir(u, NombreRol.COORDINADOR);
        if (real) reloj.usarRelojReal(); else if (fijar != null) reloj.fijar(fijar); else if (minutos != null) reloj.avanzar(minutos);
        return Map.of("ahora", reloj.now().toString(), "relojSimulado", reloj.simulado());
    }
    @PostMapping("/sim/vencer")
    public Map<String, Object> simVencer(@RequestAttribute("usuario") Usuario u) {
        exigir(u, NombreRol.COORDINADOR);
        return Map.of("reservasVencidas", reservas.vencerReservas());
    }
    @PostMapping("/sim/correo")
    public Map<String, Object> simCorreo(@RequestAttribute("usuario") Usuario u, @RequestParam ModoCorreo modo) {
        exigir(u, NombreRol.COORDINADOR);
        avisos.simularModo(modo);
        return Map.of("correo", modo.name());
    }
}
