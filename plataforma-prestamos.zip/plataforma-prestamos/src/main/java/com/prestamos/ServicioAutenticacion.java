package com.prestamos;

import com.prestamos.Enums.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Service;

/** Componente «Autenticación y Roles» (RF-18, RNF-01). */
@Service
public class ServicioAutenticacion {
    private final UsuarioRepo usuarios;
    private final Map<String, Long> sesiones = new ConcurrentHashMap<>();

    ServicioAutenticacion(UsuarioRepo usuarios) { this.usuarios = usuarios; }

    public static String hash(String clave) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(clave.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) { throw new IllegalStateException(e); }
    }

    public Map<String, Object> login(String correo, String clave) {
        Usuario u = usuarios.findByCorreo(correo == null ? "" : correo).orElse(null);
        if (u == null || clave == null || !u.passwordHash.equals(hash(clave)))
            throw new ApiException(401, "Credenciales inválidas");
        String token = UUID.randomUUID().toString();
        sesiones.put(token, u.id);
        return Map.of("token", token, "usuario", u);
    }

    public Usuario porToken(String token) {
        Long id = token == null ? null : sesiones.get(token);
        return id == null ? null : usuarios.findById(id).orElse(null);
    }

    public static void exigir(Usuario u, NombreRol... permitidos) {
        for (NombreRol r : permitidos) if (u.rol.nombre == r) return;
        throw new ApiException(403, "Su rol (" + u.rol.nombre + ") no puede ejecutar esta acción");
    }
}
