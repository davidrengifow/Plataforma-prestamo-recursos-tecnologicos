package com.prestamos;

import static com.prestamos.ServicioAutenticacion.exigir;

import com.prestamos.Enums.*;
import java.util.List;
import org.springframework.stereotype.Service;

/** Componente «Auditoría e Historial» (RN-16, RNF-08, RF-20). */
@Service
public class ServicioHistorial {
    private final HistorialRepo repo;
    private final ClockService reloj;

    ServicioHistorial(HistorialRepo repo, ClockService reloj) { this.repo = repo; this.reloj = reloj; }

    public void registrar(Usuario quien, String entidad, Long id, String accion, String detalle) {
        HistorialCambio h = new HistorialCambio();
        h.usuario = quien; // null = proceso automático del sistema
        h.entidad = entidad; h.entidadId = id; h.accion = accion; h.detalle = detalle; h.fecha = reloj.now();
        repo.save(h);
    }

    public List<HistorialCambio> listar(Usuario u) {
        exigir(u, NombreRol.COORDINADOR);
        return repo.findAllByOrderByFechaDescIdDesc();
    }
}
