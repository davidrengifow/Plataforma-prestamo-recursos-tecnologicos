package com.prestamos;

import java.util.List;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ControladorPrestamos {
    public record RetiroReq(Long reservaId, String codigoUnidad, String condicion, boolean identidadVerificada) {}
    public record DevolucionReq(String condicion, boolean dano, String descripcionDano) {}

    private final ServicioPrestamos prestamos; private final ServicioDevoluciones devoluciones; private final ServicioIncidentes incidentes;

    ControladorPrestamos(ServicioPrestamos prestamos, ServicioDevoluciones devoluciones, ServicioIncidentes incidentes) {
        this.prestamos = prestamos; this.devoluciones = devoluciones; this.incidentes = incidentes;
    }

    @GetMapping("/prestamos/mios") public List<ServicioPrestamos.PrestamoVista> mios(@RequestAttribute("usuario") Usuario u) { return prestamos.mios(u); }

    @PostMapping("/prestamos/retiro")
    public Prestamo retiro(@RequestAttribute("usuario") Usuario u, @RequestBody RetiroReq r) {
        return prestamos.retirar(u, r.reservaId(), r.codigoUnidad(), r.condicion(), r.identidadVerificada());
    }
    @PostMapping("/prestamos/{id}/devolucion")
    public ServicioDevoluciones.ResultadoDevolucion devolucion(@RequestAttribute("usuario") Usuario u, @PathVariable Long id, @RequestBody DevolucionReq r) {
        return devoluciones.devolver(u, id, r.condicion(), r.dano(), r.descripcionDano());
    }

    @GetMapping("/unidades/fuera-de-circulacion") public List<Unidad> fuera(@RequestAttribute("usuario") Usuario u) { return incidentes.fueraDeCirculacion(u); }
    @GetMapping("/unidades/{id}/afectadas") public List<Reserva> afectadas(@RequestAttribute("usuario") Usuario u, @PathVariable Long id) { return incidentes.afectadasDe(u, id); }
    @PostMapping("/unidades/{id}/habilitar") public Unidad habilitar(@RequestAttribute("usuario") Usuario u, @PathVariable Long id) { return incidentes.habilitar(u, id); }
}
