package com.prestamos;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.prestamos.Enums.*;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Rol {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @Enumerated(EnumType.STRING) @Column(unique = true)
    public NombreRol nombre;
}
