package com.prestamos;

import static com.prestamos.ServicioAutenticacion.exigir;

import com.prestamos.Enums.*;
import java.util.*;
import org.springframework.stereotype.Service;

/** Informes por sede (RF-19 / S-06): reservas por unidad, devoluciones tardías e incidentes. */
@Service
public class ServicioInformes {
    private final SedeRepo sedes; private final UnidadRepo unidades; private final ReservaRepo reservas;
    private final DevolucionRepo devoluciones; private final IncidenteRepo incidentes;

    ServicioInformes(SedeRepo sedes, UnidadRepo unidades, ReservaRepo reservas, DevolucionRepo devoluciones, IncidenteRepo incidentes) {
        this.sedes = sedes; this.unidades = unidades; this.reservas = reservas; this.devoluciones = devoluciones; this.incidentes = incidentes;
    }

    public List<Map<String, Object>> porSede(Usuario u) {
        exigir(u, NombreRol.COORDINADOR, NombreRol.DIRECCION);
        List<Map<String, Object>> salida = new ArrayList<>();
        for (Sede s : sedes.findAll()) {
            Map<String, Object> m = new LinkedHashMap<>();
            Map<String, Long> porUnidad = new TreeMap<>();
            for (Unidad un : unidades.findAll()) if (un.sede.id.equals(s.id)) porUnidad.put(un.codigo, 0L);
            for (Reserva r : reservas.findAll())
                if (r.unidad.sede.id.equals(s.id) && r.estado != EstadoReserva.CANCELADA)
                    porUnidad.merge(r.unidad.codigo, 1L, Long::sum);
            m.put("sede", s.nombre);
            m.put("reservasPorUnidad", porUnidad);
            m.put("devolucionesTardias", devoluciones.findAll().stream()
                    .filter(d -> d.tardia && d.prestamo.reserva.unidad.sede.id.equals(s.id)).count());
            m.put("incidentes", incidentes.findAll().stream().filter(i -> i.unidad.sede.id.equals(s.id)).count());
            salida.add(m);
        }
        return salida;
    }
}
