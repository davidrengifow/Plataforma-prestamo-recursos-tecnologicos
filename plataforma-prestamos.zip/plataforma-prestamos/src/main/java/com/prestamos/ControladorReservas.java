package com.prestamos;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ControladorReservas {
    public record SolicitudReq(Long tipoId, Long sedeId, LocalDateTime inicio, LocalDateTime fin) {}
    public record JustReq(String justificacion) {}

    private final ServicioReservas servicio;

    ControladorReservas(ServicioReservas servicio) { this.servicio = servicio; }

    @PostMapping("/solicitudes")
    public ServicioReservas.ResultadoSolicitud solicitar(@RequestAttribute("usuario") Usuario u, @RequestBody SolicitudReq r) {
        return servicio.solicitar(u, r.tipoId(), r.sedeId(), r.inicio(), r.fin());
    }
    @GetMapping("/solicitudes/mias") public List<Solicitud> solicitudesMias(@RequestAttribute("usuario") Usuario u) { return servicio.solicitudesMias(u); }
    @GetMapping("/solicitudes/pendientes") public List<Solicitud> pendientes(@RequestAttribute("usuario") Usuario u) { return servicio.pendientes(u); }
    @PostMapping("/solicitudes/{id}/aprobar")
    public ServicioReservas.ResultadoSolicitud aprobar(@RequestAttribute("usuario") Usuario u, @PathVariable Long id) { return servicio.aprobar(u, id); }
    @PostMapping("/solicitudes/{id}/rechazar")
    public Solicitud rechazar(@RequestAttribute("usuario") Usuario u, @PathVariable Long id, @RequestBody JustReq j) { return servicio.rechazar(u, id, j.justificacion()); }

    @GetMapping("/reservas/mias") public List<Reserva> reservasMias(@RequestAttribute("usuario") Usuario u) { return servicio.mias(u); }
    @GetMapping("/reservas/sede") public List<Reserva> reservasSede(@RequestAttribute("usuario") Usuario u) { return servicio.deLaSede(u); }
    @PostMapping("/reservas/{id}/cancelar") public Reserva cancelar(@RequestAttribute("usuario") Usuario u, @PathVariable Long id) { return servicio.cancelar(u, id); }
    @PostMapping("/reservas/{id}/reasignar") public Reserva reasignar(@RequestAttribute("usuario") Usuario u, @PathVariable Long id) { return servicio.reasignar(u, id); }
    @PostMapping("/reservas/{id}/cancelar-afectada") public Reserva cancelarAfectada(@RequestAttribute("usuario") Usuario u, @PathVariable Long id) { return servicio.cancelarAfectada(u, id); }
    @PostMapping("/usuarios/{id}/desbloquear") public Usuario desbloquear(@RequestAttribute("usuario") Usuario u, @PathVariable Long id) { return servicio.desbloquear(u, id); }
}
