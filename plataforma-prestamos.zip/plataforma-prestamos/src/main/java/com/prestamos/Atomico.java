package com.prestamos;

import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Supplier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * RN-03 / RNF-02: un único candado y una transacción completa para toda operación que asigna,
 * libera o retira una unidad. El candado es reentrante, así que un servicio puede llamar a otro.
 */
@Component
public class Atomico {
    private final ReentrantLock candado = new ReentrantLock(true);
    private final TransactionTemplate tx;

    Atomico(TransactionTemplate tx) { this.tx = tx; }

    public <T> T ejecutar(Supplier<T> trabajo) {
        candado.lock();
        try { return tx.execute(st -> trabajo.get()); } finally { candado.unlock(); }
    }
}
