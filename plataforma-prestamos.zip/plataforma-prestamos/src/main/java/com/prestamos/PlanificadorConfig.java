package com.prestamos;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

/** Planificador de vencimientos (RF-10). Se desactiva en pruebas con app.planificador.activo=false. */
@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "app.planificador.activo", havingValue = "true", matchIfMissing = true)
public class PlanificadorConfig {}
