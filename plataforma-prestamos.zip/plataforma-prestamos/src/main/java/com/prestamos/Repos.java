package com.prestamos;

import com.prestamos.Enums.*;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

interface SedeRepo extends JpaRepository<Sede, Long> {}

interface RolRepo extends JpaRepository<Rol, Long> {}

interface TipoRepo extends JpaRepository<TipoEquipo, Long> {}

interface UsuarioRepo extends JpaRepository<Usuario, Long> {
    Optional<Usuario> findByCorreo(String correo);
}

interface UnidadRepo extends JpaRepository<Unidad, Long> {
    List<Unidad> findByTipoIdAndSedeIdAndEstadoNotOrderByCodigo(Long tipoId, Long sedeId, EstadoUnidad excluido);
    List<Unidad> findByEstado(EstadoUnidad estado);
}

interface SolicitudRepo extends JpaRepository<Solicitud, Long> {
    List<Solicitud> findByEstadoOrderByCreadaAsc(EstadoSolicitud estado);
    List<Solicitud> findBySolicitanteIdOrderByCreadaDesc(Long usuarioId);
}

interface ReservaRepo extends JpaRepository<Reserva, Long> {
    @Query("select r from Reserva r where r.unidad.id = :unidadId and r.estado in :estados "
         + "and r.inicio < :fin and r.fin > :ini")
    List<Reserva> findOcupadas(@Param("unidadId") Long unidadId, @Param("ini") LocalDateTime ini,
                               @Param("fin") LocalDateTime fin, @Param("estados") Collection<EstadoReserva> estados);
    @Query("select r from Reserva r where r.estado = :estado and r.inicio < :limite "
         + "and not exists (select p.id from Prestamo p where p.reserva.id = r.id)")
    List<Reserva> findVencibles(@Param("estado") EstadoReserva estado, @Param("limite") LocalDateTime limite);
    List<Reserva> findByTitularIdOrderByInicioDesc(Long titularId);
    List<Reserva> findByUnidadSedeIdOrderByInicioAsc(Long sedeId);
    List<Reserva> findByUnidadIdAndEstado(Long unidadId, EstadoReserva estado);
    List<Reserva> findByUnidadIdAndEstadoAndInicioAfter(Long unidadId, EstadoReserva estado, LocalDateTime desde);
}

interface PrestamoRepo extends JpaRepository<Prestamo, Long> {
    List<Prestamo> findByReservaTitularIdOrderByRetiroEnDesc(Long titularId);
    Optional<Prestamo> findByReservaId(Long reservaId);
    boolean existsByReservaUnidadIdAndActivoTrue(Long unidadId);
}

interface DevolucionRepo extends JpaRepository<Devolucion, Long> {
    Optional<Devolucion> findByPrestamoId(Long prestamoId);
    @Query("select count(d) from Devolucion d where d.tardia = true and d.prestamo.reserva.titular.id = :u and d.fecha >= :desde")
    long contarTardias(@Param("u") Long usuarioId, @Param("desde") LocalDateTime desde);
}

interface IncidenteRepo extends JpaRepository<Incidente, Long> {}

interface NotificacionRepo extends JpaRepository<Notificacion, Long> {
    List<Notificacion> findAllByOrderByCreadaDesc();
}

interface HistorialRepo extends JpaRepository<HistorialCambio, Long> {
    List<HistorialCambio> findAllByOrderByFechaDescIdDesc();
}
