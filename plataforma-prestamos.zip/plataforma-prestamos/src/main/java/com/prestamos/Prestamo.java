package com.prestamos;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.prestamos.Enums.*;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Prestamo {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @ManyToOne
    public Reserva reserva;
    @ManyToOne
    public Usuario auxiliarRetiro;
    public LocalDateTime retiroEn;
    public String condicionEntrega;
    public boolean activo;
}
