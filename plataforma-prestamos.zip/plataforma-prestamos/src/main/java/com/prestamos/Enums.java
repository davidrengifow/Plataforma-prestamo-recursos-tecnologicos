package com.prestamos;

public final class Enums {
    private Enums() {}
    public enum NombreRol { ESTUDIANTE, PROFESOR, AUXILIAR, COORDINADOR, MANTENIMIENTO, DIRECCION }
    public enum EstadoUnidad { DISPONIBLE, RESERVADA, PRESTADA, FUERA_DE_CIRCULACION }
    public enum EstadoSolicitud { PENDIENTE, CONFIRMADA, RECHAZADA, NO_CONFIRMADA }
    public enum EstadoReserva { CONFIRMADA, CANCELADA, VENCIDA }
    public enum EstadoAviso { ENVIADO, PENDIENTE, FALLIDO }
    public enum ModoCorreo { OK, SIN_CONEXION, ERROR }
}
