package com.prestamos;

import java.util.Map;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ControladorAcceso {
    public record LoginReq(String correo, String password) {}

    private final ServicioAutenticacion auth;

    ControladorAcceso(ServicioAutenticacion auth) { this.auth = auth; }

    @PostMapping("/auth/login")
    public Map<String, Object> login(@RequestBody LoginReq r) { return auth.login(r.correo(), r.password()); }

    @GetMapping("/yo")
    public Usuario yo(@RequestAttribute("usuario") Usuario u) { return u; }
}
