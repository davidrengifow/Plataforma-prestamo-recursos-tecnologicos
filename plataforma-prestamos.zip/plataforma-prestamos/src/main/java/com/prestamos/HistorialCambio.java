package com.prestamos;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.prestamos.Enums.*;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class HistorialCambio {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @ManyToOne
    public Usuario usuario;
    public String entidad;
    public Long entidadId;
    public String accion;
    public String detalle;
    public LocalDateTime fecha;
}
