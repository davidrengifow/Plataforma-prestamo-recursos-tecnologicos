package com.prestamos;

import static com.prestamos.ServicioAutenticacion.exigir;

import com.prestamos.Enums.*;
import java.util.List;
import org.springframework.stereotype.Service;

/** Componente «Incidentes y Mantenimiento» (RF-14, RF-15, RF-17). */
@Service
public class ServicioIncidentes {
    public record ResultadoIncidente(Incidente incidente, List<Reserva> reservasAfectadas) {}

    private final IncidenteRepo incidentes; private final UnidadRepo unidades; private final ReservaRepo reservas;
    private final InventarioUnidad inventario; private final ServicioHistorial historial;
    private final ClockService reloj; private final Atomico atomico;

    ServicioIncidentes(IncidenteRepo incidentes, UnidadRepo unidades, ReservaRepo reservas, InventarioUnidad inventario,
                       ServicioHistorial historial, ClockService reloj, Atomico atomico) {
        this.incidentes = incidentes; this.unidades = unidades; this.reservas = reservas; this.inventario = inventario;
        this.historial = historial; this.reloj = reloj; this.atomico = atomico;
    }

    /** RN-13: registra el daño, saca la unidad de circulación y marca las reservas futuras afectadas. Se invoca desde la devolución. */
    public ResultadoIncidente registrar(Usuario aux, Devolucion devolucion, String descripcion) {
        return atomico.ejecutar(() -> {
            Unidad u = devolucion.prestamo.reserva.unidad;
            u.estado = EstadoUnidad.FUERA_DE_CIRCULACION;
            unidades.save(u);
            Incidente inc = new Incidente();
            inc.unidad = u; inc.devolucion = devolucion; inc.registradoPor = aux; inc.fecha = reloj.now();
            inc.descripcion = descripcion == null || descripcion.isBlank() ? "Daño detectado en la devolución" : descripcion;
            inc = incidentes.save(inc);
            historial.registrar(aux, "Incidente", inc.id, "REGISTRADO", u.codigo + ": " + inc.descripcion);
            historial.registrar(aux, "Unidad", u.id, "FUERA_DE_CIRCULACION", "Por incidente " + inc.id);
            List<Reserva> futuras = reservas.findByUnidadIdAndEstadoAndInicioAfter(u.id, EstadoReserva.CONFIRMADA, reloj.now());
            for (Reserva f : futuras) {
                f.afectada = true;
                reservas.save(f);
                historial.registrar(aux, "Reserva", f.id, "MARCADA_AFECTADA", "Unidad " + u.codigo + " fuera de circulación");
            }
            return new ResultadoIncidente(inc, futuras);
        });
    }

    /** RF-15: reservas futuras confirmadas marcadas como afectadas para una unidad. */
    public List<Reserva> afectadasDe(Usuario u, Long unidadId) {
        exigir(u, NombreRol.AUXILIAR, NombreRol.COORDINADOR);
        return reservas.findByUnidadIdAndEstadoAndInicioAfter(unidadId, EstadoReserva.CONFIRMADA, reloj.now()).stream()
                .filter(r -> r.afectada).toList();
    }

    public List<Unidad> fueraDeCirculacion(Usuario u) {
        exigir(u, NombreRol.AUXILIAR, NombreRol.MANTENIMIENTO, NombreRol.COORDINADOR);
        return unidades.findByEstado(EstadoUnidad.FUERA_DE_CIRCULACION);
    }

    /** RF-17: mantenimiento autoriza el regreso de la unidad. */
    public Unidad habilitar(Usuario mant, Long unidadId) {
        exigir(mant, NombreRol.MANTENIMIENTO);
        return atomico.ejecutar(() -> {
            Unidad u = unidades.findById(unidadId).orElseThrow(() -> new ApiException(404, "Unidad no encontrada"));
            if (u.estado != EstadoUnidad.FUERA_DE_CIRCULACION) throw new ApiException(409, "La unidad no está fuera de circulación");
            u.estado = EstadoUnidad.DISPONIBLE;
            unidades.save(u);
            for (Reserva r : reservas.findByUnidadIdAndEstado(u.id, EstadoReserva.CONFIRMADA))
                if (r.afectada) { r.afectada = false; reservas.save(r); }
            inventario.sincronizarEstado(u); // RESERVADA si conserva reservas futuras
            historial.registrar(mant, "Unidad", u.id, "HABILITADA", "Regresa a circulación: " + u.codigo);
            return u;
        });
    }
}
