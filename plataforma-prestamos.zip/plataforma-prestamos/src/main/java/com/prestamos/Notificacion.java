package com.prestamos;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.prestamos.Enums.*;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Notificacion {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    public Long solicitudId;
    public Long reservaId;
    @ManyToOne
    public Usuario destinatario;
    public String evento;
    @Enumerated(EnumType.STRING)
    public EstadoAviso estado;
    public String detalle;
    public LocalDateTime creada;
}
