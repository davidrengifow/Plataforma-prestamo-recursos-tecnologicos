package com.prestamos;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.prestamos.Enums.*;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Devolucion {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @ManyToOne
    public Prestamo prestamo;
    @ManyToOne
    public Usuario auxiliar;
    public LocalDateTime fecha;
    public String condicion;
    public boolean tardia;
}
