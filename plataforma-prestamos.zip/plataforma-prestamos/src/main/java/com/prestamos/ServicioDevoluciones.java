package com.prestamos;

import static com.prestamos.ServicioAutenticacion.exigir;

import com.prestamos.Enums.*;
import java.util.List;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/** Componente «Préstamos y Devoluciones» (parte de devolución, RF-12, RF-13). */
@Service
public class ServicioDevoluciones {
    public record ResultadoDevolucion(Prestamo prestamo, Devolucion devolucion, Incidente incidente, List<Reserva> reservasAfectadas) {}

    private final PrestamoRepo prestamos; private final DevolucionRepo devoluciones; private final UsuarioRepo usuarios;
    private final InventarioUnidad inventario; private final ServicioIncidentes incidentes; private final ServicioHistorial historial;
    private final ClockService reloj; private final Atomico atomico; private final int umbralBloqueo;

    ServicioDevoluciones(PrestamoRepo prestamos, DevolucionRepo devoluciones, UsuarioRepo usuarios, InventarioUnidad inventario,
                         ServicioIncidentes incidentes, ServicioHistorial historial, ClockService reloj, Atomico atomico,
                         @Value("${app.bloqueo.umbral:2}") int umbralBloqueo) {
        this.prestamos = prestamos; this.devoluciones = devoluciones; this.usuarios = usuarios; this.inventario = inventario;
        this.incidentes = incidentes; this.historial = historial; this.reloj = reloj; this.atomico = atomico; this.umbralBloqueo = umbralBloqueo;
    }

    /** RN-12 / RN-13: cierra el préstamo, marca la devolución tardía y gestiona el daño con sus reservas afectadas. */
    public ResultadoDevolucion devolver(Usuario aux, Long prestamoId, String condicion, boolean dano, String descripcionDano) {
        exigir(aux, NombreRol.AUXILIAR);
        return atomico.ejecutar(() -> {
            Prestamo p = prestamos.findById(prestamoId).orElseThrow(() -> new ApiException(404, "Préstamo no encontrado"));
            Reserva r = p.reserva;
            if (!aux.sede.id.equals(r.unidad.sede.id)) throw new ApiException(403, "Solo puede operar en su sede");
            if (!p.activo) throw new ApiException(409, "El préstamo ya fue cerrado");
            Devolucion d = new Devolucion();
            d.prestamo = p; d.auxiliar = aux; d.fecha = reloj.now(); d.condicion = condicion;
            d.tardia = d.fecha.isAfter(r.fin); // S-04: hora pactada = fin de la franja
            d = devoluciones.save(d);
            p.activo = false;
            prestamos.save(p);
            historial.registrar(aux, "Devolucion", d.id, d.tardia ? "DEVOLUCION_TARDIA" : "DEVOLUCION", condicion);
            if (d.tardia) aplicarBloqueoSiCorresponde(aux, r.titular);

            Incidente inc = null;
            List<Reserva> afectadas = List.of();
            if (dano) {
                ServicioIncidentes.ResultadoIncidente res = incidentes.registrar(aux, d, descripcionDano);
                inc = res.incidente();
                afectadas = res.reservasAfectadas();
            } else {
                inventario.sincronizarEstado(r.unidad); // vuelve a DISPONIBLE o RESERVADA
            }
            return new ResultadoDevolucion(p, d, inc, afectadas);
        });
    }

    /** S-01: bloqueo tras N devoluciones tardías en 30 días (N configurable). */
    private void aplicarBloqueoSiCorresponde(Usuario aux, Usuario titular) {
        long tardias = devoluciones.contarTardias(titular.id, reloj.now().minusDays(30));
        Usuario t = usuarios.findById(titular.id).orElseThrow();
        t.devolucionesTardias30d = (int) tardias;
        if (tardias >= umbralBloqueo && !t.bloqueado) {
            t.bloqueado = true;
            historial.registrar(aux, "Usuario", t.id, "BLOQUEADO", tardias + " devoluciones tardías en 30 días");
        }
        usuarios.save(t);
    }
}
