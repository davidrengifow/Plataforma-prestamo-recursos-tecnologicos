package com.prestamos;

import static com.prestamos.ServicioAutenticacion.exigir;

import com.prestamos.Enums.*;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/** Componente «Servicio de Reservas» (RF-03 a RF-08, RF-10, RF-11). */
@Service
public class ServicioReservas {
    public record ResultadoSolicitud(Solicitud solicitud, Reserva reserva) {}

    private final InventarioUnidad inventario; private final SedeRepo sedes; private final SolicitudRepo solicitudes;
    private final ReservaRepo reservas; private final UsuarioRepo usuarios; private final PrestamoRepo prestamos;
    private final ServicioHistorial historial; private final ServicioNotificaciones avisos; private final ClockService reloj;
    private final Atomico atomico; private final int minutosVencimiento;

    ServicioReservas(InventarioUnidad inventario, SedeRepo sedes, SolicitudRepo solicitudes, ReservaRepo reservas,
                     UsuarioRepo usuarios, PrestamoRepo prestamos, ServicioHistorial historial, ServicioNotificaciones avisos,
                     ClockService reloj, Atomico atomico, @Value("${app.vencimiento.minutos:30}") int minutosVencimiento) {
        this.inventario = inventario; this.sedes = sedes; this.solicitudes = solicitudes; this.reservas = reservas;
        this.usuarios = usuarios; this.prestamos = prestamos; this.historial = historial; this.avisos = avisos;
        this.reloj = reloj; this.atomico = atomico; this.minutosVencimiento = minutosVencimiento;
    }

    // ---------- Consultas ----------

    public List<Reserva> mias(Usuario u) { return reservas.findByTitularIdOrderByInicioDesc(u.id); }

    public List<Solicitud> solicitudesMias(Usuario u) { return solicitudes.findBySolicitanteIdOrderByCreadaDesc(u.id); }

    public List<Reserva> deLaSede(Usuario aux) {
        exigir(aux, NombreRol.AUXILIAR);
        return reservas.findByUnidadSedeIdOrderByInicioAsc(aux.sede.id);
    }

    public List<Solicitud> pendientes(Usuario coord) {
        exigir(coord, NombreRol.COORDINADOR);
        return solicitudes.findByEstadoOrderByCreadaAsc(EstadoSolicitud.PENDIENTE);
    }

    /** RN-04 / RN-07: devuelve el motivo si la persona no puede reservar, o null si es elegible. */
    public String validarElegibilidad(Usuario u) {
        Usuario actual = usuarios.findById(u.id).orElse(u);
        return actual.bloqueado ? "La cuenta está bloqueada por devoluciones tardías (RN-04)" : null;
    }

    // ---------- Solicitudes ----------

    public ResultadoSolicitud solicitar(Usuario u, Long tipoId, Long sedeId, LocalDateTime ini, LocalDateTime fin) {
        exigir(u, NombreRol.ESTUDIANTE, NombreRol.PROFESOR);
        String inelegible = validarElegibilidad(u);
        if (inelegible != null) throw new ApiException(403, inelegible);
        InventarioUnidad.validarFranja(ini, fin);
        return atomico.ejecutar(() -> {
            TipoEquipo tipo = inventario.tipo(tipoId);
            Sede sede = sedes.findById(sedeId).orElseThrow(() -> new ApiException(404, "Sede no encontrada"));
            Solicitud s = new Solicitud();
            s.solicitante = u; s.tipo = tipo; s.sede = sede; s.inicio = ini; s.fin = fin; s.creada = reloj.now();
            if (tipo.especializado) {
                s.estado = EstadoSolicitud.PENDIENTE; // RN-06: no ocupa unidad mientras espera
                s = solicitudes.save(s);
                historial.registrar(u, "Solicitud", s.id, "CREADA", "Pendiente de autorización del coordinador");
                return new ResultadoSolicitud(s, null);
            }
            Unidad unidad = inventario.buscarUnidadDisponible(tipo, sede.id, ini, fin);
            if (unidad == null) throw new ApiException(409, "No hay unidad disponible de «" + tipo.nombre + "» en esa sede y franja");
            s.estado = EstadoSolicitud.CONFIRMADA;
            s = solicitudes.save(s);
            return new ResultadoSolicitud(s, confirmar(s, unidad, u, "CONFIRMADA automáticamente"));
        });
    }

    public ResultadoSolicitud aprobar(Usuario coord, Long solicitudId) {
        exigir(coord, NombreRol.COORDINADOR);
        return atomico.ejecutar(() -> {
            Solicitud s = pendiente(solicitudId);
            String motivo = validarElegibilidad(s.solicitante); // RN-07: revalidar elegibilidad
            Unidad unidad = null;
            if (motivo == null) {
                unidad = inventario.buscarUnidadDisponible(s.tipo, s.sede.id, s.inicio, s.fin); // y disponibilidad
                if (unidad == null) motivo = "Ya no hay unidad disponible en la franja solicitada";
            }
            if (motivo != null) { // S-05
                s.estado = EstadoSolicitud.NO_CONFIRMADA; s.motivo = motivo;
                solicitudes.save(s);
                historial.registrar(coord, "Solicitud", s.id, "APROBACION_FALLIDA", motivo);
                avisos.avisar(s.solicitante, s.id, null, "NO_CONFIRMADA", motivo);
                return new ResultadoSolicitud(s, null);
            }
            s.estado = EstadoSolicitud.CONFIRMADA;
            solicitudes.save(s);
            return new ResultadoSolicitud(s, confirmar(s, unidad, coord, "APROBADA por coordinador"));
        });
    }

    public Solicitud rechazar(Usuario coord, Long solicitudId, String justificacion) {
        exigir(coord, NombreRol.COORDINADOR);
        if (justificacion == null || justificacion.isBlank()) throw new ApiException(400, "El rechazo exige una justificación (RN-08)");
        return atomico.ejecutar(() -> {
            Solicitud s = pendiente(solicitudId);
            s.estado = EstadoSolicitud.RECHAZADA; s.motivo = justificacion;
            solicitudes.save(s);
            historial.registrar(coord, "Solicitud", s.id, "RECHAZADA", justificacion);
            avisos.avisar(s.solicitante, s.id, null, "RECHAZADA", justificacion);
            return s;
        });
    }

    // ---------- Cancelación, vencimiento, reasignación ----------

    public Reserva cancelar(Usuario u, Long reservaId) {
        return atomico.ejecutar(() -> {
            Reserva r = reservas.findById(reservaId).orElseThrow(() -> new ApiException(404, "Reserva no encontrada"));
            if (!r.titular.id.equals(u.id)) throw new ApiException(403, "Solo el titular puede cancelar su reserva (RN-11)");
            if (prestamos.findByReservaId(r.id).isPresent())
                throw new ApiException(409, "Ya se registró el retiro; la reserva no se puede cancelar (RN-11)");
            if (r.estado != EstadoReserva.CONFIRMADA)
                throw new ApiException(409, "La reserva ya no se puede cancelar (estado " + r.estado + ")");
            r.estado = EstadoReserva.CANCELADA;
            reservas.save(r);
            inventario.sincronizarEstado(r.unidad);
            historial.registrar(u, "Reserva", r.id, "CANCELADA", "Cancelada por su titular");
            avisos.avisar(r.titular, r.solicitud.id, r.id, "CANCELADA", "Reserva cancelada por su titular");
            return r;
        });
    }

    /** RN-10 / S-07: vence la reserva sin retiro si pasaron más de 30 minutos desde el inicio. Lo invoca el planificador. */
    public int vencerReservas() {
        return atomico.ejecutar(() -> {
            LocalDateTime limite = reloj.now().minusMinutes(minutosVencimiento);
            List<Reserva> vencidas = reservas.findVencibles(EstadoReserva.CONFIRMADA, limite);
            for (Reserva r : vencidas) {
                r.estado = EstadoReserva.VENCIDA;
                reservas.save(r);
                inventario.sincronizarEstado(r.unidad);
                historial.registrar(null, "Reserva", r.id, "VENCIDA", "Sin retiro tras " + minutosVencimiento + " minutos");
                avisos.avisar(r.titular, r.solicitud.id, r.id, "VENCIDA", "Reserva vencida por falta de retiro");
            }
            return vencidas.size();
        });
    }

    /** S-03: el auxiliar mueve una reserva afectada a otra unidad libre del mismo tipo y sede. */
    public Reserva reasignar(Usuario aux, Long reservaId) {
        exigir(aux, NombreRol.AUXILIAR);
        return atomico.ejecutar(() -> {
            Reserva r = afectada(aux, reservaId);
            Unidad nueva = inventario.buscarUnidadDisponible(r.unidad.tipo, r.unidad.sede.id, r.inicio, r.fin);
            if (nueva == null) throw new ApiException(409, "No hay otra unidad libre para reasignar; cancele y avise a la persona");
            String antes = r.unidad.codigo;
            r.unidad = nueva; r.afectada = false;
            reservas.save(r);
            inventario.sincronizarEstado(nueva);
            historial.registrar(aux, "Reserva", r.id, "REASIGNADA", antes + " -> " + nueva.codigo);
            return r;
        });
    }

    public Reserva cancelarAfectada(Usuario aux, Long reservaId) {
        exigir(aux, NombreRol.AUXILIAR);
        return atomico.ejecutar(() -> {
            Reserva r = afectada(aux, reservaId);
            r.estado = EstadoReserva.CANCELADA;
            reservas.save(r);
            historial.registrar(aux, "Reserva", r.id, "CANCELADA_POR_AVERIA", "Unidad " + r.unidad.codigo + " fuera de circulación");
            avisos.avisar(r.titular, r.solicitud.id, r.id, "CANCELADA", "Su unidad quedó fuera de circulación por una avería");
            return r;
        });
    }

    public Usuario desbloquear(Usuario coord, Long usuarioId) {
        exigir(coord, NombreRol.COORDINADOR);
        return atomico.ejecutar(() -> {
            Usuario u = usuarios.findById(usuarioId).orElseThrow(() -> new ApiException(404, "Usuario no encontrado"));
            u.bloqueado = false;
            usuarios.save(u);
            historial.registrar(coord, "Usuario", u.id, "DESBLOQUEADO", u.correo);
            return u;
        });
    }

    // ---------- Internos ----------

    private Reserva confirmar(Solicitud s, Unidad unidad, Usuario quien, String detalle) {
        Reserva r = new Reserva();
        r.solicitud = s; r.unidad = unidad; r.titular = s.solicitante;
        r.inicio = s.inicio; r.fin = s.fin; r.estado = EstadoReserva.CONFIRMADA;
        r = reservas.save(r);
        inventario.sincronizarEstado(unidad); // la unidad pasa a RESERVADA
        historial.registrar(quien, "Reserva", r.id, "CONFIRMADA", detalle + " - unidad " + unidad.codigo);
        avisos.avisar(s.solicitante, s.id, r.id, "CONFIRMADA", "Reserva de " + s.tipo.nombre + " (" + unidad.codigo + ")");
        return r;
    }

    private Solicitud pendiente(Long id) {
        Solicitud s = solicitudes.findById(id).orElseThrow(() -> new ApiException(404, "Solicitud no encontrada"));
        if (s.estado != EstadoSolicitud.PENDIENTE) throw new ApiException(409, "La solicitud ya fue resuelta (" + s.estado + ")");
        return s;
    }

    private Reserva afectada(Usuario aux, Long id) {
        Reserva r = reservas.findById(id).orElseThrow(() -> new ApiException(404, "Reserva no encontrada"));
        if (!aux.sede.id.equals(r.unidad.sede.id)) throw new ApiException(403, "Solo puede operar en su sede");
        if (!r.afectada || r.estado != EstadoReserva.CONFIRMADA) throw new ApiException(409, "La reserva no está marcada como afectada");
        return r;
    }
}
