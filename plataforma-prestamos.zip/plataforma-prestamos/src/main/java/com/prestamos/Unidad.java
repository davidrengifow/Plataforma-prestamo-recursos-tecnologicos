package com.prestamos;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.prestamos.Enums.*;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Unidad {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @Column(unique = true)
    public String codigo;
    @ManyToOne
    public TipoEquipo tipo;
    @ManyToOne
    public Sede sede;
    @Enumerated(EnumType.STRING)
    public EstadoUnidad estado;
}
