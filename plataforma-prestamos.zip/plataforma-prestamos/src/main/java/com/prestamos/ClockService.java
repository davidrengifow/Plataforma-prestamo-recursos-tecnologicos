package com.prestamos;

import java.time.LocalDateTime;
import org.springframework.stereotype.Service;

/** Reloj de la aplicación. Permite fijar la hora para demostrar el vencimiento (RN-10). */
@Service
public class ClockService {
    private volatile LocalDateTime fijo;

    public LocalDateTime now() {
        LocalDateTime f = fijo;
        return f != null ? f : LocalDateTime.now().withNano(0);
    }
    public void fijar(LocalDateTime t) { this.fijo = t; }
    public void avanzar(long minutos) { this.fijo = now().plusMinutes(minutos); }
    public void usarRelojReal() { this.fijo = null; }
    public boolean simulado() { return fijo != null; }
}
