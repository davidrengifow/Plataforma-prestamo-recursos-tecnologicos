package com.prestamos;

import static org.junit.jupiter.api.Assertions.*;

import com.prestamos.Enums.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

/** Escenarios del apartado 9 del proyecto. Cada prueba arranca con la base de datos limpia. */
@SpringBootTest(properties = "app.planificador.activo=false")
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
class FlujosPrincipalesTest {
    @Autowired ServicioReservas reservas;
    @Autowired ServicioPrestamos prestamos;
    @Autowired ServicioDevoluciones devoluciones;
    @Autowired ServicioIncidentes incidentes;
    @Autowired InventarioUnidad inventario;
    @Autowired ServicioNotificaciones avisos;
    @Autowired ClockService reloj;
    @Autowired UsuarioRepo usuarios;
    @Autowired TipoRepo tipos;
    @Autowired SedeRepo sedes;
    @Autowired UnidadRepo unidades;

    Usuario est1, est2, auxNorte, auxSur, coord, mant;
    Long camara, robotica, norte;
    LocalDateTime base;

    @BeforeEach
    void preparar() {
        est1 = u("estudiante1@demo.edu"); est2 = u("estudiante2@demo.edu");
        auxNorte = u("auxiliar.norte@demo.edu"); auxSur = u("auxiliar.sur@demo.edu");
        coord = u("coordinador@demo.edu"); mant = u("mantenimiento@demo.edu");
        camara = tipos.findAll().stream().filter(t -> t.nombre.equals("Cámara")).findFirst().orElseThrow().id;
        robotica = tipos.findAll().stream().filter(t -> t.nombre.startsWith("Kit")).findFirst().orElseThrow().id;
        norte = sedes.findAll().stream().filter(s -> s.nombre.equals("Sede Norte")).findFirst().orElseThrow().id;
        reloj.usarRelojReal();
        base = LocalDateTime.now().plusDays(2).withHour(10).withMinute(0).withSecond(0).withNano(0);
    }

    Usuario u(String correo) { return usuarios.findByCorreo(correo).orElseThrow(); }
    LocalDateTime h(int horas, int min) { return base.plusHours(horas).plusMinutes(min); }

    // CP-01 · RF-04 confirmación estándar y aviso
    @Test
    void confirmacionEstandar() {
        var r = reservas.solicitar(est1, camara, norte, h(0, 0), h(1, 0));
        assertEquals(EstadoSolicitud.CONFIRMADA, r.solicitud().estado);
        assertEquals(EstadoReserva.CONFIRMADA, r.reserva().estado);
        assertEquals(EstadoAviso.ENVIADO, avisos.listar().get(0).estado);
    }

    // CP-02 · RN-02 franjas consecutivas válidas y superpuestas rechazadas
    @Test
    void franjasConsecutivas() {
        reservas.solicitar(est1, camara, norte, h(0, 0), h(1, 0));
        assertNotNull(reservas.solicitar(est2, camara, norte, h(1, 0), h(2, 0)).reserva());
        ApiException e = assertThrows(ApiException.class, () -> reservas.solicitar(est2, camara, norte, h(0, 30), h(1, 30)));
        assertEquals(409, e.status);
    }

    // CP-03 · RN-03 / RNF-02 dos solicitudes simultáneas por la última unidad
    @Test
    void ultimaUnidadConcurrente() throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(2);
        CountDownLatch salida = new CountDownLatch(1);
        AtomicInteger ok = new AtomicInteger(), rechazadas = new AtomicInteger();
        List<Future<?>> fs = new ArrayList<>();
        for (Usuario us : List.of(est1, est2)) {
            fs.add(pool.submit(() -> {
                try {
                    salida.await();
                    reservas.solicitar(us, camara, norte, h(3, 0), h(4, 0));
                    ok.incrementAndGet();
                } catch (ApiException e) { rechazadas.incrementAndGet(); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            }));
        }
        salida.countDown();
        for (Future<?> f : fs) f.get(10, TimeUnit.SECONDS);
        pool.shutdown();
        assertEquals(1, ok.get());
        assertEquals(1, rechazadas.get());
    }

    // CP-04 · RN-07 / S-05 aprobación cuando la disponibilidad cambió
    @Test
    void aprobacionConRevalidacion() {
        var a = reservas.solicitar(est1, robotica, norte, h(0, 0), h(1, 0));
        var b = reservas.solicitar(est2, robotica, norte, h(0, 0), h(1, 0));
        assertEquals(EstadoSolicitud.PENDIENTE, a.solicitud().estado);
        assertNull(a.reserva()); // RN-06: no ocupa unidad
        assertEquals(EstadoSolicitud.CONFIRMADA, reservas.aprobar(coord, a.solicitud().id).solicitud().estado);
        var segunda = reservas.aprobar(coord, b.solicitud().id);
        assertEquals(EstadoSolicitud.NO_CONFIRMADA, segunda.solicitud().estado);
        assertNotNull(segunda.solicitud().motivo);
    }

    // CP-05 · RN-08 rechazo con y sin justificación
    @Test
    void rechazoExigeJustificacion() {
        var a = reservas.solicitar(est1, robotica, norte, h(0, 0), h(1, 0));
        assertEquals(400, assertThrows(ApiException.class, () -> reservas.rechazar(coord, a.solicitud().id, " ")).status);
        assertEquals(EstadoSolicitud.RECHAZADA, reservas.rechazar(coord, a.solicitud().id, "Sin curso asociado").estado);
    }

    // CP-06 · RN-11 cancelación por titular y por otra persona
    @Test
    void cancelacion() {
        var r = reservas.solicitar(est1, camara, norte, h(0, 0), h(1, 0)).reserva();
        assertEquals(403, assertThrows(ApiException.class, () -> reservas.cancelar(est2, r.id)).status);
        assertEquals(EstadoReserva.CANCELADA, reservas.cancelar(est1, r.id).estado);
        assertNotNull(reservas.solicitar(est2, camara, norte, h(0, 0), h(1, 0)).reserva()); // unidad liberada
    }

    // CP-07 · RN-10 / S-07 vencimiento: válido hasta el minuto 30, vence en el 31
    @Test
    void vencimientoSinRetiro() {
        var r = reservas.solicitar(est1, camara, norte, h(0, 0), h(1, 0)).reserva();
        reloj.fijar(h(0, 30));
        assertEquals(0, reservas.vencerReservas());
        reloj.fijar(h(0, 31));
        assertEquals(1, reservas.vencerReservas());
        assertEquals(EstadoReserva.VENCIDA, reservas.mias(est1).get(0).estado);
        assertEquals(409, assertThrows(ApiException.class, () -> reservas.cancelar(est1, r.id)).status);
    }

    // CP-08 · RN-12 / RN-13 retiro, devolución tardía y daño con reservas afectadas; reactivación
    @Test
    void devolucionTardiaConDanoYReactivacion() {
        var r1 = reservas.solicitar(est1, camara, norte, h(0, 0), h(1, 0)).reserva();
        var r2 = reservas.solicitar(est2, camara, norte, h(5, 0), h(6, 0)).reserva();
        reloj.fijar(h(0, 5));
        assertEquals(403, assertThrows(ApiException.class,
                () -> prestamos.retirar(auxSur, r1.id, "CAM-N-01", "ok", true)).status); // otra sede
        Prestamo p = prestamos.retirar(auxNorte, r1.id, "CAM-N-01", "Sin daños", true);
        reloj.fijar(h(1, 10));
        var dev = devoluciones.devolver(auxNorte, p.id, "Lente rayado", true, "Lente roto");
        assertTrue(dev.devolucion().tardia);
        assertNotNull(dev.incidente());
        assertEquals(1, dev.reservasAfectadas().size());
        assertEquals(r2.id, dev.reservasAfectadas().get(0).id);
        assertEquals(1, incidentes.fueraDeCirculacion(auxNorte).size());
        assertEquals(0, inventario.disponibles(camara, norte, h(7, 0), h(8, 0)).size());
        incidentes.habilitar(mant, dev.incidente().unidad.id);
        assertEquals(1, inventario.disponibles(camara, norte, h(7, 0), h(8, 0)).size());
    }

    // CP-09 · RN-14 / RNF-05 fallo de correo no revierte la reserva
    @Test
    void falloDeCorreoNoRevierteReserva() {
        avisos.simularModo(ModoCorreo.ERROR);
        var r = reservas.solicitar(est1, camara, norte, h(0, 0), h(1, 0));
        assertEquals(EstadoReserva.CONFIRMADA, r.reserva().estado);
        assertEquals(EstadoAviso.FALLIDO, avisos.listar().get(0).estado);
        avisos.simularModo(ModoCorreo.OK);
        assertEquals(EstadoAviso.ENVIADO, avisos.reintentar(avisos.listar().get(0).id).estado);
        // sede con conexión intermitente: el aviso queda PENDIENTE y la reserva sigue confirmada
        avisos.simularModo(ModoCorreo.SIN_CONEXION);
        var r2 = reservas.solicitar(est2, camara, norte, h(5, 0), h(6, 0));
        assertEquals(EstadoReserva.CONFIRMADA, r2.reserva().estado);
        assertTrue(avisos.listar().stream().anyMatch(n -> n.estado == EstadoAviso.PENDIENTE));
    }

    // CP-10 · RN-15 / RNF-06 privacidad y permisos por rol
    @Test
    void permisosYPrivacidad() {
        reservas.solicitar(est1, camara, norte, h(0, 0), h(1, 0));
        assertEquals(1, reservas.mias(est1).size());
        assertEquals(0, reservas.mias(est2).size());
        assertEquals(403, assertThrows(ApiException.class, () -> reservas.aprobar(est1, 1L)).status);
        assertEquals(403, assertThrows(ApiException.class, () -> incidentes.habilitar(auxNorte, 1L)).status);
    }

    // CP-11 · S-01 bloqueo tras dos devoluciones tardías
    @Test
    void bloqueoPorTardanzas() {
        for (int i = 0; i < 2; i++) {
            var r = reservas.solicitar(est1, camara, norte, h(i * 3, 0), h(i * 3 + 1, 0)).reserva();
            reloj.fijar(h(i * 3, 5));
            Prestamo p = prestamos.retirar(auxNorte, r.id, "CAM-N-01", "ok", true);
            reloj.fijar(h(i * 3 + 2, 0));
            devoluciones.devolver(auxNorte, p.id, "ok", false, null);
        }
        assertTrue(u("estudiante1@demo.edu").bloqueado);
        assertEquals(403, assertThrows(ApiException.class,
                () -> reservas.solicitar(u("estudiante1@demo.edu"), camara, norte, h(8, 0), h(9, 0))).status);
        reservas.desbloquear(coord, est1.id);
        assertFalse(u("estudiante1@demo.edu").bloqueado);
    }

    // CP-12 · diagrama de estados de la unidad: DISPONIBLE -> RESERVADA -> PRESTADA -> DISPONIBLE
    @Test
    void estadosDeLaUnidad() {
        assertEquals(EstadoUnidad.DISPONIBLE, estadoCamara());
        var r = reservas.solicitar(est1, camara, norte, h(0, 0), h(1, 0)).reserva();
        assertEquals(EstadoUnidad.RESERVADA, estadoCamara());
        reloj.fijar(h(0, 5));
        Prestamo p = prestamos.retirar(auxNorte, r.id, "CAM-N-01", "ok", true);
        assertEquals(EstadoUnidad.PRESTADA, estadoCamara());
        assertEquals(EstadoReserva.CONFIRMADA, reservas.mias(est1).get(0).estado); // el retiro no cambia el estado de la reserva
        assertEquals(409, assertThrows(ApiException.class, () -> reservas.cancelar(est1, r.id)).status); // RN-11
        reloj.fijar(h(0, 50));
        var dev = devoluciones.devolver(auxNorte, p.id, "ok", false, null);
        assertFalse(dev.devolucion().tardia);
        assertEquals(p.id, dev.devolucion().prestamo.id); // Devolucion -> Prestamo
        assertEquals(EstadoUnidad.DISPONIBLE, estadoCamara());
    }

    // CP-13 · modelo: Rol como entidad, Incidente ligado a Devolucion y Unidad
    @Test
    void modeloRolDevolucionIncidente() {
        assertEquals(NombreRol.ESTUDIANTE, est1.rol.nombre);
        assertNotNull(est1.rol.id);
        var r = reservas.solicitar(est1, camara, norte, h(0, 0), h(1, 0)).reserva();
        reloj.fijar(h(0, 5));
        Prestamo p = prestamos.retirar(auxNorte, r.id, "CAM-N-01", "ok", true);
        reloj.fijar(h(0, 40));
        var dev = devoluciones.devolver(auxNorte, p.id, "Pantalla rota", true, "Lente roto");
        assertEquals(dev.devolucion().id, dev.incidente().devolucion.id);
        assertEquals("CAM-N-01", dev.incidente().unidad.codigo);
        assertEquals(EstadoUnidad.FUERA_DE_CIRCULACION, estadoCamara());
    }

    EstadoUnidad estadoCamara() {
        return unidades.findAll().stream().filter(x -> x.codigo.equals("CAM-N-01")).findFirst().orElseThrow().estado;
    }
}
